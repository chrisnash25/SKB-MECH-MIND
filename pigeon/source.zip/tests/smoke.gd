extends SceneTree

func _initialize() -> void:
    call_deferred("run_tests")

func run_tests() -> void:
    var scene = load("res://scenes/main.tscn")
    if scene == null:
        push_error("Missing main scene")
        quit(1)
        return
    var game = scene.instantiate()
    root.add_child(game)
    await process_frame
    await process_frame
    if game.get("player") == null:
        push_error("Pigeon player missing")
        quit(1)
        return
    if not (game.get("camera") != null):
        push_error("Camera missing")
        quit(1)
        return
    if not (game.get("chip_nodes").size() == 24):
        push_error("Chip count incorrect")
        quit(1)
        return
    if not (game.get("people").size() == 35):
        push_error("Pedestrians missing")
        quit(1)
        return
    if not (game.get("cars").size() == 12):
        push_error("Cars missing")
        quit(1)
        return
    if not (game.get("map_overlay") != null):
        push_error("Map missing")
        quit(1)
        return
    if not (game.get("title_overlay") != null):
        push_error("Menu missing")
        quit(1)
        return
    game.call("_start_game")
    game.call("_flap")
    if not (game.get("in_flight")):
        push_error("Flap failed")
        quit(1)
        return
    game.call("_fire_poop")
    if not (game.get("projectiles").size() > 0):
        push_error("Poop projectile missing")
        quit(1)
        return
    game.call("_toggle_map")
    if not (game.get("map_open")):
        push_error("Map toggle failed")
        quit(1)
        return
    game.call("_toggle_map")
    game.call("_toggle_pause")
    if not (game.get("paused")):
        push_error("Pause toggle failed")
        quit(1)
        return
    game.call("_toggle_pause")
    print("PIGEON_SMOKE_PASS player camera map menu flap poop pedestrians cars chips")
    quit(0)
