extends Control

var player_pos := Vector3.ZERO
var landmarks := [
    ["BROADMEAD", Vector2(20, -125)],
    ["CABOT CIRCUS", Vector2(175, -135)],
    ["CASTLE PARK", Vector2(150, 10)],
    ["OLD CITY", Vector2(-30, 5)],
    ["COLLEGE GREEN", Vector2(-165, 95)],
    ["QUEEN SQUARE", Vector2(-65, 185)],
    ["HARBOURSIDE", Vector2(-135, 145)]
]

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE

func to_map(pos: Vector2) -> Vector2:
    return Vector2((pos.x + 275.0) / 550.0 * size.x, (pos.y + 260.0) / 520.0 * size.y)

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.065, 0.105, 0.14, 0.96), true)
    var park := Rect2(to_map(Vector2(95, -30)), to_map(Vector2(235, 70)) - to_map(Vector2(95, -30)))
    draw_rect(park, Color(0.19, 0.42, 0.27))
    var water_a := to_map(Vector2(-265, 143))
    var water_b := to_map(Vector2(265, 143))
    draw_line(water_a, water_b, Color(0.12, 0.5, 0.69), 19.0, true)
    for i in range(-225, 250, 85):
        draw_line(to_map(Vector2(i, -250)), to_map(Vector2(i, 245)), Color(0.31, 0.37, 0.39), 7.0, true)
    for i in range(-215, 250, 80):
        draw_line(to_map(Vector2(-260, i)), to_map(Vector2(260, i)), Color(0.31, 0.37, 0.39), 7.0, true)
    for entry in landmarks:
        var p: Vector2 = to_map(entry[1])
        draw_circle(p, 5.0, Color(1.0, 0.79, 0.23))
        draw_string(ThemeDB.fallback_font, p + Vector2(8, -6), entry[0], HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
    var me := to_map(Vector2(player_pos.x, player_pos.z))
    draw_circle(me, 9.0, Color(0.05, 0.05, 0.06))
    draw_circle(me, 6.5, Color(1.0, 0.22, 0.35))
    draw_arc(me, 13.0, 0.0, TAU, 32, Color.WHITE, 1.5)
