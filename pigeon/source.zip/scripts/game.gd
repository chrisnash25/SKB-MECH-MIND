extends Node3D

# GRAND THEFT PIGEON: SHIT HAPPENS — Bristol city-centre vertical slice.
# New procedural Bristol-inspired world. DROPZONE-style Xbox controls, independent game.
const MAP_SCRIPT = preload("res://scripts/map_view.gd")
const FLAP = preload("res://audio/flap.wav")
const SPLAT = preload("res://audio/splat.wav")
const CHIP = preload("res://audio/chip.wav")
const COO = preload("res://audio/coo.wav")
const WORLD_LIMIT := 255.0
const MOVE_SPEED := 12.0
const FLIGHT_SPEED := 20.0
const GRAVITY := 11.5
const DEADZONE := 0.19

var rng := RandomNumberGenerator.new()
var mats := {}
var player: CharacterBody3D
var bird_visual: Node3D
var wing_l: Node3D
var wing_r: Node3D
var camera: Camera3D
var camera_yaw := -1.5
var camera_pitch := 0.22
var fly_velocity := 0.0
var in_flight := false
var game_time := 0.0
var firing_cd := 0.0
var flapping_cd := 0.0
var chips := 0
var splats := 0
var chaos := 0
var mission_stage := 0
var projectiles := []
var chip_nodes := []
var people := []
var cars := []
var ui: CanvasLayer
var hud: Label
var objective: Label
var notice: Label
var title_overlay: Control
var pause_overlay: Control
var map_overlay: Control
var map_view: Control
var mobile_controls: Control
var notice_time := 0.0
var started := false
var paused := false
var map_open := false
var touch_move_id := -1
var touch_look_id := -1
var touch_origin := Vector2.ZERO
var touch_motion := Vector2.ZERO
var touch_look_delta := Vector2.ZERO
var touch_fly_held := false
var sound_player: AudioStreamPlayer

func _ready() -> void:
    rng.seed = 20261121
    _setup_world()
    _make_city()
    _make_player()
    _make_pickups()
    _make_pedestrians()
    _make_cars()
    _make_ui()
    sound_player = AudioStreamPlayer.new()
    sound_player.volume_db = -9.0
    add_child(sound_player)
    _update_hud()
    set_process(true)
    set_physics_process(true)

func _material(c: Color, metallic: float = 0.0, rough: float = 0.8, transparency: bool = false) -> StandardMaterial3D:
    var key := c.to_html(true) + "_" + str(metallic) + "_" + str(rough) + "_" + str(transparency)
    if mats.has(key):
        return mats[key]
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.metallic = metallic
    m.roughness = rough
    if transparency:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_ALWAYS
    mats[key] = m
    return m

func _box(parent: Node3D, at: Vector3, sz: Vector3, color: Color, solid: bool = false, metal: float = 0.0) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = sz
    m.mesh = mesh
    m.material_override = _material(color, metal)
    m.position = at
    parent.add_child(m)
    if solid:
        var body := StaticBody3D.new()
        var shape := CollisionShape3D.new()
        var b := BoxShape3D.new()
        b.size = sz
        shape.shape = b
        body.add_child(shape)
        body.position = at
        parent.add_child(body)
    return m

func _sphere(parent: Node3D, at: Vector3, scale_vec: Vector3, color: Color) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radial_segments = 12
    mesh.rings = 6
    var m := MeshInstance3D.new()
    m.mesh = mesh
    m.position = at
    m.scale = scale_vec
    m.material_override = _material(color)
    parent.add_child(m)
    return m

func _cylinder(parent: Node3D, at: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = 9
    var m := MeshInstance3D.new()
    m.mesh = mesh
    m.position = at
    m.material_override = _material(color)
    parent.add_child(m)
    return m

func _label(parent: Node3D, name: String, at: Vector3, size_px: int = 38, color: Color = Color.WHITE, face_camera: bool = true) -> Label3D:
    var l := Label3D.new()
    l.text = name
    l.position = at
    l.font_size = size_px
    l.pixel_size = 0.020
    l.modulate = color
    l.outline_size = 8
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED if face_camera else BaseMaterial3D.BILLBOARD_DISABLED
    l.no_depth_test = false
    parent.add_child(l)
    return l

func _setup_world() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color(0.54, 0.73, 0.91)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.77, 0.83, 0.94)
    e.ambient_light_energy = 0.58
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-51, -30, 0)
    sun.light_energy = 1.05
    sun.shadow_enabled = false # WebGL-safe default
    add_child(sun)
    _box(self, Vector3(0, -1.1, 0), Vector3(540, 2.0, 540), Color(0.27, 0.33, 0.35), true)
    _box(self, Vector3(0, -0.06, 0), Vector3(530, 0.12, 530), Color(0.48, 0.47, 0.44))
    for x in [-215, -130, -45, 40, 125, 210]:
        _box(self, Vector3(x, 0.035, 0), Vector3(13, 0.09, 530), Color(0.23, 0.27, 0.3))
        _box(self, Vector3(x - 7.7, 0.09, 0), Vector3(2.0, 0.16, 530), Color(0.68, 0.67, 0.62))
        _box(self, Vector3(x + 7.7, 0.09, 0), Vector3(2.0, 0.16, 530), Color(0.68, 0.67, 0.62))
    for z in [-210, -130, -50, 30, 110, 190]:
        _box(self, Vector3(0, 0.04, z), Vector3(530, 0.09, 13), Color(0.23, 0.27, 0.3))
        _box(self, Vector3(0, 0.09, z - 7.7), Vector3(530, 0.16, 2.0), Color(0.68, 0.67, 0.62))
        _box(self, Vector3(0, 0.09, z + 7.7), Vector3(530, 0.16, 2.0), Color(0.68, 0.67, 0.62))
    # The floating harbour is a stylised west-east water corridor with three crossings.
    _box(self, Vector3(0, 0.13, 151), Vector3(530, 0.22, 34), Color(0.1, 0.39, 0.57))
    for x in [-130, 40, 210]:
        _box(self, Vector3(x, 0.35, 151), Vector3(14, 0.6, 38), Color(0.55, 0.53, 0.47), true)
        for side in [-1, 1]:
            _box(self, Vector3(x + side * 6.0, 1.05, 151), Vector3(0.25, 1.2, 37), Color(0.22, 0.3, 0.33), false, 0.6)
    _label(self, "BRISTOL CITY CENTRE", Vector3(-15, 46, -224), 66, Color(1, 0.88, 0.45))

func _make_city() -> void:
    # District positions follow Bristol's broad north/south/east/west relationships.
    var district_names := [
        ["BROADMEAD", Vector3(5, 17, -116)],
        ["CABOT CIRCUS", Vector3(168, 27, -150)],
        ["CASTLE PARK", Vector3(155, 15, 5)],
        ["OLD CITY", Vector3(-32, 18, 0)],
        ["COLLEGE GREEN", Vector3(-167, 16, 90)],
        ["QUEEN SQUARE", Vector3(-55, 18, 207)],
        ["HARBOURSIDE", Vector3(-138, 16, 130)]
    ]
    for d in district_names:
        _label(self, d[0], d[1], 60, Color(1, 0.9, 0.49))
    _make_parks()
    _make_building_blocks()
    _make_shopping_quarter()
    _make_landmarks()
    _make_street_furniture()
    _make_pavement_details()

func _make_building_blocks() -> void:
    var colors := [Color("bba995"), Color("b7b9b5"), Color("aa8473"), Color("d1b99c"), Color("7f9298"), Color("c9c8bf"), Color("9f776a")]
    for row in range(6):
        for col in range(6):
            var x: float = -174.0 + col * 83.0
            var z: float = -173.0 + row * 80.0
            if x > 80 and x < 250 and z > -55 and z < 85:
                continue # Castle Park
            if z > 112 and z < 194:
                continue # Harbourside and Queen Square
            if x < -98 and z > 36 and z < 130:
                continue # College Green
            if z < -75 and z > -200 and x > -80 and x < 235:
                continue # Broadmead / Cabot Circus shops
            var h := rng.randf_range(14.0, 35.0)
            var c: Color = colors[rng.randi_range(0, colors.size() - 1)]
            _building(Vector3(x, 0, z), Vector3(52, h, 50), c, "")

func _building(pos: Vector3, dims: Vector3, wall_color: Color, sign_text: String) -> void:
    var b := Node3D.new()
    b.position = pos
    add_child(b)
    _box(b, Vector3(0, dims.y * 0.5, 0), dims, wall_color, true)
    _box(b, Vector3(0, dims.y + 0.3, 0), Vector3(dims.x + 1, 0.6, dims.z + 1), Color(0.21, 0.26, 0.29))
    _box(b, Vector3(0, 1.7, dims.z * 0.5 + 0.1), Vector3(dims.x * 0.76, 3.0, 0.12), Color(0.15, 0.27, 0.31), false, 0.35)
    var count := int(min(6, floor(dims.x / 6.0)))
    var levels := int(min(6, floor(dims.y / 5.0)))
    for floor_idx in range(1, levels):
        for j in range(count):
            var wx: float = -dims.x * 0.43 + j * (dims.x * 0.86 / max(1, count - 1))
            _box(b, Vector3(wx, floor_idx * 4.5 + 2.8, dims.z * 0.5 + 0.08), Vector3(2.6, 2.7, 0.12), Color(0.18, 0.28, 0.34), false, 0.3)
            _box(b, Vector3(wx, floor_idx * 4.5 + 2.8, dims.z * 0.5 + 0.17), Vector3(0.10, 2.7, 0.1), Color(0.8, 0.79, 0.74))
    if sign_text != "":
        _box(b, Vector3(0, 4.2, dims.z * 0.5 + 0.28), Vector3(dims.x * 0.85, 2.4, 0.2), Color(0.08, 0.11, 0.16))
        _label(b, sign_text, Vector3(0, 4.3, dims.z * 0.5 + 0.48), 48, Color(1, 0.9, 0.53))

func _make_shopping_quarter() -> void:
    var shops := ["PRIMARK", "BOOTS", "TK MAXX", "CHIP PALACE", "BIRD MART", "GREGGS", "BARGAIN BARN", "COFFEE NEST", "THE ARCADE", "SNEAKER DEN", "FEATHER FASHION", "PASTRY KING"]
    for side in [-1, 1]:
        for i in range(6):
            var x := -68.0 + i * 27.0
            var z: float = -108.0 + float(side) * 26.0
            var col := Color(0.52 + (i % 3) * 0.08, 0.49 + (i % 4) * 0.05, 0.45 + (i % 2) * 0.09)
            _building(Vector3(x, 0, z), Vector3(23, 18 + i % 3 * 4, 19), col, shops[i + (0 if side < 0 else 6)])
    # Cabot Circus: multi-storey retail wings and a glass arcade roof.
    _building(Vector3(163, 0, -182), Vector3(69, 30, 25), Color("b9b3a8"), "CABOT CIRCUS")
    _building(Vector3(163, 0, -96), Vector3(69, 25, 25), Color("c2a998"), "THE GALLERIES")
    for z in range(-164, -105, 10):
        _box(self, Vector3(163, 19.0, float(z)), Vector3(77, 0.25, 6), Color(0.57, 0.78, 0.81, 0.62))
        _box(self, Vector3(163, 19.3, float(z)), Vector3(77, 0.18, 0.18), Color(0.26, 0.34, 0.39), false, 0.6)
    _box(self, Vector3(20, 0.18, -108), Vector3(146, 0.25, 23), Color("bdb9b1"))
    for i in range(10):
        _cylinder(self, Vector3(-67 + i * 16, 0.9, -108), 0.26, 1.7, Color(0.19, 0.23, 0.25))

func _make_parks() -> void:
    # Castle Park: lawn, ruins and rows of trees.
    _box(self, Vector3(164, 0.17, 13), Vector3(133, 0.24, 108), Color("43835b"))
    _box(self, Vector3(165, 0.31, 15), Vector3(4, 0.08, 106), Color("b8b5a3"))
    _box(self, Vector3(165, 0.31, 15), Vector3(132, 0.08, 4), Color("b8b5a3"))
    for i in range(7):
        _tree(Vector3(115 + i * 17, 0.3, -22), 1.0)
        _tree(Vector3(115 + i * 17, 0.3, 52), 1.1)
    # Castle ruins / St Peter's-inspired fragment.
    for x in [128.0, 141.0, 154.0]:
        _box(self, Vector3(x, 5.3, 17), Vector3(3, 10.5, 2.8), Color("8c8071"), true)
    _box(self, Vector3(141, 11, 17), Vector3(29, 2.0, 2.8), Color("918779"))
    # College Green: open grass and cathedral-inspired silhouette.
    _box(self, Vector3(-175, 0.18, 84), Vector3(90, 0.25, 64), Color("508c60"))
    for i in range(6):
        _tree(Vector3(-211 + i * 14, 0.25, 110), 0.8)
    # Queen Square, green with paths and central monument.
    _box(self, Vector3(-57, 0.19, 210), Vector3(97, 0.25, 62), Color("4b8658"))
    _box(self, Vector3(-57, 0.32, 210), Vector3(4, 0.1, 63), Color("b4afa0"))
    _box(self, Vector3(-57, 0.32, 210), Vector3(98, 0.1, 4), Color("b4afa0"))
    _cylinder(self, Vector3(-57, 2.2, 210), 2.0, 4.0, Color("a6a298"))
    for i in range(5):
        _tree(Vector3(-97 + i * 20, 0.3, 188), 0.9)
        _tree(Vector3(-97 + i * 20, 0.3, 233), 0.9)

func _tree(pos: Vector3, scale_factor: float) -> void:
    var t := Node3D.new()
    t.position = pos
    t.scale = Vector3.ONE * scale_factor
    add_child(t)
    _cylinder(t, Vector3(0, 2.4, 0), 0.35, 4.8, Color("73533b"))
    _sphere(t, Vector3(0, 5.3, 0), Vector3(3.2, 3.5, 3.2), Color(0.15 + rng.randf() * 0.1, 0.39 + rng.randf() * 0.13, 0.21))
    _sphere(t, Vector3(1.3, 4.7, 0.6), Vector3(2.3, 2.6, 2.3), Color("327447"))

func _make_landmarks() -> void:
    # Cathedral-inspired massing and tall square tower (not a survey-accurate model).
    _building(Vector3(-211, 0, 67), Vector3(29, 29, 25), Color("c0a78b"), "BRISTOL CATHEDRAL")
    _box(self, Vector3(-221, 24, 55), Vector3(10, 48, 10), Color("c1aa8f"), true)
    _box(self, Vector3(-201, 24, 55), Vector3(10, 48, 10), Color("c1aa8f"), true)
    _label(self, "COLLEGE GREEN", Vector3(-167, 5, 84), 37, Color("f9f4d2"))
    # Old City / St Nick's Market-inspired covered arcade.
    _building(Vector3(-45, 0, 3), Vector3(46, 19, 30), Color("ad8d76"), "ST NICK'S MARKET")
    _box(self, Vector3(-45, 21.5, 3), Vector3(50, 3.0, 33), Color("5a655f"))
    # Bristol's recognisable waterfront colour palette, piers and boat.
    for x in [-185, -158, -100, -66, -12, 83, 125]:
        _box(self, Vector3(x, 0.46, 132), Vector3(15, 0.65, 4), Color("aaa596"))
        _cylinder(self, Vector3(x - 5, 1.5, 130), 0.3, 2.6, Color("333a3a"))
    _box(self, Vector3(-120, 0.8, 150), Vector3(23, 1.8, 7), Color("854e38"))
    _box(self, Vector3(-120, 3.5, 150), Vector3(14, 4.0, 5), Color("e6ded0"))
    _label(self, "FLOATING HARBOUR", Vector3(-132, 9, 145), 38, Color("b8efff"))
    # Castle Bridge and decorative pylons.
    for x in [32, 48]:
        for z in [134, 168]:
            _cylinder(self, Vector3(x, 2.6, z), 0.28, 5.2, Color("c7c7c5"))

func _make_street_furniture() -> void:
    for i in range(55):
        var x := rng.randf_range(-235, 235)
        var z := rng.randf_range(-230, 225)
        if absf(z - 151) < 23 or (x > 98 and x < 233 and z > -38 and z < 70):
            continue
        _cylinder(self, Vector3(x, 3.1, z), 0.17, 6.2, Color("394247"))
        _sphere(self, Vector3(x, 6.3, z), Vector3(0.8, 0.32, 0.8), Color("f6e8b7"))
    for i in range(40):
        var x := rng.randf_range(-235, 235)
        var z := rng.randf_range(-220, 235)
        _box(self, Vector3(x, 0.48, z), Vector3(1.5, 0.8, 0.8), Color("776c5e"))
    for i in range(25):
        var x := rng.randf_range(-230, 230)
        var z := rng.randf_range(-210, 225)
        _cylinder(self, Vector3(x, 0.55, z), 0.22, 1.1, Color("3d4549"))

func _make_pavement_details() -> void:
    # Pedestrian shopping streets: paving, planters, crossing stripes, café furniture.
    for i in range(32):
        var x := -75.0 + float(i) * 5.2
        _box(self, Vector3(x, 0.29, -108), Vector3(0.16, 0.05, 20.0), Color("8f8f8a"))
    for i in range(10):
        var x := -60.0 + float(i) * 17.0
        for side in [-1, 1]:
            var z: float = -108.0 + float(side) * 11.0
            _box(self, Vector3(x, 0.5, z), Vector3(3.5, 0.9, 1.4), Color("7a7771"))
            _sphere(self, Vector3(x, 1.3, z), Vector3(1.3, 0.8, 0.85), Color("37794e"))
    for x in [-130.0, -45.0, 40.0, 125.0]:
        for j in range(6):
            _box(self, Vector3(x - 5.0 + j * 2.0, 0.22, -109), Vector3(1.0, 0.07, 13.0), Color("ecebe4"))
    for i in range(12):
        var x := -80.0 + float(i) * 23.0
        var z := 123.0
        _box(self, Vector3(x, 0.5, z), Vector3(3.5, 0.65, 0.8), Color("79634b"))
        _box(self, Vector3(x - 1.4, 0.25, z), Vector3(0.2, 0.9, 0.8), Color("42494a"))
        _box(self, Vector3(x + 1.4, 0.25, z), Vector3(0.2, 0.9, 0.8), Color("42494a"))

func _make_player() -> void:
    player = CharacterBody3D.new()
    player.name = "PigeonPlayer"
    player.position = Vector3(-24, 2.0, -109)
    player.floor_snap_length = 0.35
    add_child(player)
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.46
    capsule.height = 1.25
    shape.shape = capsule
    player.add_child(shape)
    bird_visual = Node3D.new()
    bird_visual.name = "PigeonVisual"
    bird_visual.rotation.y = -1.5
    player.add_child(bird_visual)
    var grey := Color("6b7885")
    _sphere(bird_visual, Vector3(0, 0.08, 0.08), Vector3(0.85, 0.55, 1.15), grey)
    _sphere(bird_visual, Vector3(0, 0.46, -0.68), Vector3(0.48, 0.56, 0.49), Color("7c8996"))
    _sphere(bird_visual, Vector3(0, 0.28, -0.88), Vector3(0.51, 0.25, 0.35), Color("42918b"))
    _sphere(bird_visual, Vector3(0, 0.18, -0.73), Vector3(0.48, 0.22, 0.37), Color("684b8c"))
    _sphere(bird_visual, Vector3(0, -0.13, -0.5), Vector3(0.6, 0.37, 0.56), Color("8c9aa7"))
    for side in [-1, 1]:
        _sphere(bird_visual, Vector3(side * 0.35, 0.58, -0.93), Vector3(0.18, 0.2, 0.14), Color.WHITE)
        _sphere(bird_visual, Vector3(side * 0.4, 0.6, -1.06), Vector3(0.085, 0.105, 0.06), Color("121b24"))
        _box(bird_visual, Vector3(side * 0.29, -0.43, 0.15), Vector3(0.11, 0.5, 0.11), Color("d75550"))
    _sphere(bird_visual, Vector3(0, 0.33, -1.22), Vector3(0.2, 0.13, 0.39), Color("efc658"))
    _box(bird_visual, Vector3(0, 0.12, 1.2), Vector3(0.64, 0.14, 1.1), Color("525e6c"))
    for i in range(5):
        _box(bird_visual, Vector3(-0.25 + i * 0.12, 0.12, 1.75), Vector3(0.13, 0.06, 0.65), Color("566573"))
    for side in [-1, 1]:
        _sphere(bird_visual, Vector3(float(side) * 0.25, -0.48, -0.14), Vector3(0.18, 0.12, 0.28), Color("e56e58"))
        for toe in range(3):
            _box(bird_visual, Vector3(float(side) * 0.25 + (toe - 1) * 0.11, -0.58, -0.35), Vector3(0.07, 0.08, 0.38), Color("d45a4c"))
    wing_l = Node3D.new()
    wing_r = Node3D.new()
    wing_l.position = Vector3(-0.65, 0.17, 0.12)
    wing_r.position = Vector3(0.65, 0.17, 0.12)
    bird_visual.add_child(wing_l)
    bird_visual.add_child(wing_r)
    _box(wing_l, Vector3(-0.85, 0, 0.1), Vector3(1.9, 0.12, 0.72), Color("4c5a68"))
    _box(wing_r, Vector3(0.85, 0, 0.1), Vector3(1.9, 0.12, 0.72), Color("4c5a68"))
    for i in range(5):
        var offset := 0.4 + float(i) * 0.29
        _box(wing_l, Vector3(-offset, -0.035, 0.45), Vector3(0.2, 0.08, 0.65), Color("5b6977"))
        _box(wing_r, Vector3(offset, -0.035, 0.45), Vector3(0.2, 0.08, 0.65), Color("5b6977"))
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 75.0
    add_child(camera)
    camera.position = player.position + Vector3(0, 5, 10)
    camera.look_at(player.position)

func _make_pickups() -> void:
    for i in range(24):
        var p := Node3D.new()
        p.name = "ChipPickup"
        var pos := Vector3(rng.randf_range(-195, 198), 1.0, rng.randf_range(-210, 208))
        if absf(pos.z - 151) < 23:
            pos.z -= 34
        p.position = pos
        add_child(p)
        _box(p, Vector3.ZERO, Vector3(1.1, 0.35, 0.7), Color("edc453"))
        for k in range(5):
            _box(p, Vector3(-0.38 + k * 0.19, 0.28, 0), Vector3(0.12, 0.45 + 0.12 * k, 0.14), Color("eecf68"))
        _label(p, "CHIPS!", Vector3(0, 2.1, 0), 30, Color("fff59a"))
        chip_nodes.append(p)

func _make_pedestrians() -> void:
    var shirts := [Color("e6a15a"), Color("3b7192"), Color("9b5868"), Color("5a8c74"), Color("aaa0bd"), Color("323c4e")]
    for i in range(35):
        var p := Node3D.new()
        p.position = Vector3(rng.randf_range(-220, 220), 0.3, rng.randf_range(-220, 220))
        if absf(p.position.z - 151) < 22:
            p.position.z -= 30
        add_child(p)
        _cylinder(p, Vector3(0, 1.05, 0), 0.34, 1.3, shirts[i % shirts.size()])
        _sphere(p, Vector3(0, 2.0, 0), Vector3(0.33, 0.36, 0.31), Color("c6a080"))
        for side in [-1, 1]:
            _box(p, Vector3(side * 0.17, 0.32, 0), Vector3(0.18, 0.65, 0.2), Color("363d49"))
        people.append({"node":p, "dir":Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1)).normalized(), "panic":0.0, "phase":rng.randf_range(0, TAU)})

func _make_cars() -> void:
    var palette := [Color("b73e3e"), Color("2f556d"), Color("d1d4d4"), Color("262a31"), Color("d3a74a")]
    for i in range(12):
        var car := Node3D.new()
        var horizontal := i % 2 == 0
        car.position = Vector3(-230 + i * 36, 0.5, -210 + (i % 5) * 80)
        add_child(car)
        var col: Color = palette[i % palette.size()]
        _box(car, Vector3(0, 0.8, 0), Vector3(3.2, 1.2, 5.2), col)
        _box(car, Vector3(0, 1.7, -0.2), Vector3(2.8, 1.0, 2.8), Color("344b56"))
        for side in [-1, 1]:
            for z in [-1.7, 1.7]:
                _cylinder(car, Vector3(side * 1.7, 0.35, z), 0.65, 0.25, Color("1c2024"))
        cars.append({"node":car, "horizontal":horizontal, "speed":rng.randf_range(5.0, 9.0)})

func _make_ui() -> void:
    ui = CanvasLayer.new()
    ui.layer = 10
    add_child(ui)
    var hud_bar := ColorRect.new()
    hud_bar.color = Color(0.04, 0.08, 0.11, 0.84)
    hud_bar.anchor_right = 1.0
    hud_bar.offset_bottom = 83
    hud_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(hud_bar)
    hud = _ui_label(ui, "", 19, Vector2(24, 12), Vector2(900, 34), Color("ffffff"))
    objective = _ui_label(ui, "", 17, Vector2(24, 46), Vector2(1000, 30), Color("f9d57c"))
    notice = _ui_label(ui, "", 22, Vector2(0, 97), Vector2(950, 35), Color("fff4b5"))
    notice.anchor_left = 0.5
    notice.anchor_right = 0.5
    notice.offset_left = -475
    notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var help := _ui_label(ui, "WASD / Left stick: move   •   Mouse / Right stick: look   •   Space / A: flap   •   X / RT: poop   •   Shift / B: dive   •   E / Y: steal chips   •   Tab / View: map   •   Esc / Start: menu", 13, Vector2(20, -43), Vector2(1220, 28), Color("e6eef2"))
    help.anchor_top = 1.0
    help.anchor_bottom = 1.0
    help.mouse_filter = Control.MOUSE_FILTER_IGNORE
    title_overlay = _overlay("GRAND THEFT PIGEON", "SHIT HAPPENS\n\nBRISTOL CITY CENTRE\nFly anywhere. Steal chips. Terrorise the pavement.\n\nA ridiculous free-roam pigeon adventure.", "START THE CHAOS", func(): _start_game())
    pause_overlay = _overlay("PAUSED", "The people of Bristol are briefly safe.\n\nA = Flap   B = Dive   X = Poop   Y = Steal chips\nStart = Menu   Select = Map", "RESUME", func(): _toggle_pause())
    pause_overlay.visible = false
    map_overlay = ColorRect.new()
    map_overlay.color = Color(0.02, 0.05, 0.08, 0.96)
    map_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    map_overlay.visible = false
    ui.add_child(map_overlay)
    var map_title := _ui_label(map_overlay, "BRISTOL — PIGEON'S EYE VIEW", 32, Vector2(40, 20), Vector2(800, 52), Color("ffdb75"))
    map_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
    map_view = Control.new()
    map_view.set_script(MAP_SCRIPT)
    map_view.anchor_right = 1.0
    map_view.anchor_bottom = 1.0
    map_view.offset_left = 45
    map_view.offset_top = 88
    map_view.offset_right = -45
    map_view.offset_bottom = -85
    map_overlay.add_child(map_view)
    _ui_button(map_overlay, "CLOSE MAP", Vector2(-198, 20), Vector2(160, 48), func(): _toggle_map(), true)
    _make_touch_buttons()

func _ui_label(parent: Node, txt: String, font_size: int, pos: Vector2, sz: Vector2, color: Color) -> Label:
    var l := Label.new()
    l.text = txt
    l.position = pos
    l.size = sz
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
    l.add_theme_constant_override("shadow_offset_x", 2)
    l.add_theme_constant_override("shadow_offset_y", 2)
    parent.add_child(l)
    return l

func _ui_button(parent: Node, txt: String, pos: Vector2, sz: Vector2, action: Callable, right_anchor: bool = false) -> Button:
    var b := Button.new()
    b.text = txt
    b.position = pos
    b.size = sz
    b.add_theme_font_size_override("font_size", 21)
    if right_anchor:
        b.anchor_left = 1.0
        b.anchor_right = 1.0
    b.pressed.connect(action)
    parent.add_child(b)
    return b

func _overlay(heading: String, subheading: String, button_text: String, action: Callable) -> Control:
    var layer := ColorRect.new()
    layer.color = Color(0.025, 0.05, 0.08, 0.95)
    layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(layer)
    var header := _ui_label(layer, heading, 54, Vector2(0, 110), Vector2(1280, 80), Color("ffdb69"))
    header.anchor_right = 1.0
    header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var subtitle := _ui_label(layer, subheading, 24, Vector2(0, 230), Vector2(1280, 220), Color("e5f4ff"))
    subtitle.anchor_right = 1.0
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _ui_button(layer, button_text, Vector2(510, 520), Vector2(260, 70), action)
    return layer

func _make_touch_buttons() -> void:
    mobile_controls = Control.new()
    mobile_controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mobile_controls.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(mobile_controls)
    var btn_a := _ui_button(mobile_controls, "A  FLAP", Vector2(-170, -165), Vector2(144, 57), func(): _flap(), true)
    var btn_b := _ui_button(mobile_controls, "B  DIVE", Vector2(-324, -95), Vector2(144, 57), func(): _dive(), true)
    var btn_x := _ui_button(mobile_controls, "X  POOP", Vector2(-170, -95), Vector2(144, 57), func(): _fire_poop(), true)
    var btn_y := _ui_button(mobile_controls, "Y  CHIPS", Vector2(-324, -165), Vector2(144, 57), func(): _steal_chips(), true)
    for b in [btn_a, btn_b, btn_x, btn_y]:
        b.anchor_top = 1.0
        b.anchor_bottom = 1.0
    var btn_map := _ui_button(mobile_controls, "MAP", Vector2(-155, 95), Vector2(115, 46), func(): _toggle_map(), true)
    var btn_menu := _ui_button(mobile_controls, "MENU", Vector2(-285, 95), Vector2(115, 46), func(): _toggle_pause(), true)
    btn_map.add_theme_font_size_override("font_size", 16)
    btn_menu.add_theme_font_size_override("font_size", 16)
    mobile_controls.visible = DisplayServer.is_touchscreen_available()

func _start_game() -> void:
    started = true
    paused = false
    title_overlay.visible = false
    Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED if not DisplayServer.is_touchscreen_available() else Input.MOUSE_MODE_VISIBLE)
    _notify("MISSION 1: STEAL FIVE PORTIONS OF CHIPS!", 5.0)

func _toggle_pause() -> void:
    if not started or map_open:
        return
    paused = not paused
    pause_overlay.visible = paused
    if paused:
        Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    elif not DisplayServer.is_touchscreen_available():
        Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _toggle_map() -> void:
    if not started or paused:
        return
    map_open = not map_open
    map_overlay.visible = map_open
    if map_open:
        map_view.set("player_pos", player.position)
        map_view.queue_redraw()
        Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
    elif not DisplayServer.is_touchscreen_available():
        Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _input(event: InputEvent) -> void:
    if event is InputEventJoypadButton and event.pressed:
        match event.button_index:
            JOY_BUTTON_START:
                if started:
                    _toggle_pause()
                else:
                    _start_game()
            JOY_BUTTON_BACK:
                _toggle_map()
            JOY_BUTTON_A:
                _flap()
            JOY_BUTTON_B:
                _dive()
            JOY_BUTTON_X:
                _fire_poop()
            JOY_BUTTON_Y:
                _steal_chips()
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_ESCAPE:
                _toggle_pause()
            KEY_TAB, KEY_M:
                _toggle_map()
            KEY_SPACE:
                _flap()
            KEY_E:
                _steal_chips()
            KEY_F:
                _fire_poop()
            KEY_SHIFT:
                _dive()
            KEY_ENTER:
                if not started:
                    _start_game()
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and started and not paused and not map_open:
        camera_yaw -= event.relative.x * 0.0028
        camera_pitch = clampf(camera_pitch + event.relative.y * 0.0022, -0.35, 0.85)
    if event is InputEventScreenTouch and started and not paused and not map_open:
        var width := get_viewport().get_visible_rect().size.x
        var height := get_viewport().get_visible_rect().size.y
        if event.pressed:
            if event.position.y > height * 0.68 and event.position.x > width * 0.69:
                return # Face buttons are on the right.
            if event.position.x < width * 0.48 and touch_move_id < 0:
                touch_move_id = event.index
                touch_origin = event.position
                touch_motion = Vector2.ZERO
            elif event.position.x >= width * 0.48 and touch_look_id < 0:
                touch_look_id = event.index
        else:
            if event.index == touch_move_id:
                touch_move_id = -1
                touch_motion = Vector2.ZERO
            if event.index == touch_look_id:
                touch_look_id = -1
    if event is InputEventScreenDrag and started and not paused and not map_open:
        if event.index == touch_move_id:
            touch_motion = (event.position - touch_origin) / 80.0
            touch_motion = touch_motion.limit_length(1.0)
        elif event.index == touch_look_id:
            camera_yaw -= event.relative.x * 0.005
            camera_pitch = clampf(camera_pitch + event.relative.y * 0.004, -0.35, 0.85)

func _get_pad() -> int:
    var ids := Input.get_connected_joypads()
    return ids[0] if ids.size() > 0 else -1

func _pad_axis(pad: int, axis: int) -> float:
    if pad < 0:
        return 0.0
    var v := Input.get_joy_axis(pad, axis)
    return v if absf(v) >= DEADZONE else 0.0

func _physics_process(delta: float) -> void:
    if not started or paused or map_open:
        return
    game_time += delta
    firing_cd = maxf(0.0, firing_cd - delta)
    flapping_cd = maxf(0.0, flapping_cd - delta)
    var pad := _get_pad()
    var input_dir := Vector2.ZERO
    if Input.is_key_pressed(KEY_A):
        input_dir.x -= 1.0
    if Input.is_key_pressed(KEY_D):
        input_dir.x += 1.0
    if Input.is_key_pressed(KEY_W):
        input_dir.y -= 1.0
    if Input.is_key_pressed(KEY_S):
        input_dir.y += 1.0
    if pad >= 0:
        var stick := Vector2(_pad_axis(pad, JOY_AXIS_LEFT_X), _pad_axis(pad, JOY_AXIS_LEFT_Y))
        if stick.length() > 0.15:
            input_dir = stick
        if Input.get_joy_axis(pad, JOY_AXIS_TRIGGER_RIGHT) > 0.55:
            _fire_poop()
        if Input.is_joy_button_pressed(pad, JOY_BUTTON_A) and flapping_cd <= 0:
            _flap()
        camera_yaw -= _pad_axis(pad, JOY_AXIS_RIGHT_X) * delta * 2.4
        camera_pitch = clampf(camera_pitch + _pad_axis(pad, JOY_AXIS_RIGHT_Y) * delta * 1.8, -0.35, 0.85)
    if touch_move_id >= 0:
        input_dir = touch_motion
    input_dir = input_dir.limit_length(1.0)
    if Input.is_key_pressed(KEY_SPACE) and flapping_cd <= 0:
        _flap()
    var direction := Vector3(input_dir.x, 0, input_dir.y).rotated(Vector3.UP, camera_yaw)
    var speed := FLIGHT_SPEED if in_flight else MOVE_SPEED
    if in_flight and (Input.is_key_pressed(KEY_SHIFT) or (pad >= 0 and Input.is_joy_button_pressed(pad, JOY_BUTTON_B))):
        speed *= 1.6
        fly_velocity -= 14.0 * delta
    player.velocity.x = direction.x * speed
    player.velocity.z = direction.z * speed
    if in_flight:
        fly_velocity -= GRAVITY * 0.48 * delta
        player.velocity.y = fly_velocity
    else:
        player.velocity.y -= GRAVITY * delta
    player.move_and_slide()
    if player.is_on_floor():
        in_flight = false
        fly_velocity = 0.0
    if player.position.y > 105:
        player.position.y = 105
        fly_velocity = minf(0.0, fly_velocity)
    player.position.x = clampf(player.position.x, -WORLD_LIMIT, WORLD_LIMIT)
    player.position.z = clampf(player.position.z, -WORLD_LIMIT, WORLD_LIMIT)
    if direction.length() > 0.1:
        bird_visual.rotation.y = lerp_angle(bird_visual.rotation.y, atan2(-direction.x, -direction.z), delta * 7.0)
    var flap_phase := sin(game_time * (17.0 if in_flight else 4.0))
    wing_l.rotation.y = 0.0 if in_flight else 1.15
    wing_r.rotation.y = 0.0 if in_flight else -1.15
    wing_l.rotation.z = flap_phase * 0.72 if in_flight else 0.04
    wing_r.rotation.z = -flap_phase * 0.72 if in_flight else -0.04
    bird_visual.position.y = sin(game_time * 4.0) * 0.06 if in_flight else 0.0
    _tick_projectiles(delta)
    _tick_people(delta)
    _tick_cars(delta)
    _tick_pickups(delta)

func _process(delta: float) -> void:
    if not is_instance_valid(camera) or not is_instance_valid(player):
        return
    var focus := player.global_position + Vector3(0, 1.0, 0)
    var distance := 9.5 if in_flight else 7.0
    var camera_offset := Vector3(0, 2.5 + camera_pitch * 9.0, distance).rotated(Vector3.UP, camera_yaw)
    var desired := focus + camera_offset
    camera.global_position = camera.global_position.lerp(desired, clampf(delta * 6.0, 0, 1))
    camera.look_at(focus + Vector3(0, camera_pitch * 2.0, 0), Vector3.UP)
    if notice_time > 0:
        notice_time -= delta
        if notice_time <= 0:
            notice.text = ""
    if map_open:
        map_view.set("player_pos", player.position)
        map_view.queue_redraw()

func _flap() -> void:
    if not started or paused or map_open or flapping_cd > 0:
        return
    in_flight = true
    fly_velocity = maxf(7.2, fly_velocity + 4.5)
    flapping_cd = 0.32
    _sound(FLAP)

func _dive() -> void:
    if not started or paused or map_open:
        return
    if in_flight:
        fly_velocity = minf(fly_velocity, -11.0)
        _notify("DIVE BOMB!", 1.3)

func _fire_poop() -> void:
    if not started or paused or map_open or firing_cd > 0:
        return
    firing_cd = 0.24
    var front := Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))
    var shot := Node3D.new()
    shot.position = player.global_position + Vector3(0, -0.3, 0) + front * 1.5
    add_child(shot)
    _sphere(shot, Vector3.ZERO, Vector3(0.22, 0.19, 0.22), Color("f4f2dc"))
    projectiles.append({"node":shot, "vel":front * (19.0 if in_flight else 25.0) + Vector3(0, -5.0, 0), "life":3.5})
    if splats == 0:
        _notify("THE FIRST SHOT HAS BEEN FIRED.", 2.2)

func _tick_projectiles(delta: float) -> void:
    for i in range(projectiles.size() - 1, -1, -1):
        var entry = projectiles[i]
        var node: Node3D = entry["node"]
        var old_pos: Vector3 = node.global_position
        var vel: Vector3 = entry["vel"]
        vel.y -= 19.0 * delta
        var next_pos := old_pos + vel * delta
        var query := PhysicsRayQueryParameters3D.create(old_pos, next_pos)
        query.exclude = [player.get_rid()]
        var hit := get_world_3d().direct_space_state.intersect_ray(query)
        if not hit.is_empty():
            _splat(hit["position"])
            node.queue_free()
            projectiles.remove_at(i)
            continue
        node.global_position = next_pos
        entry["vel"] = vel
        entry["life"] = float(entry["life"]) - delta
        projectiles[i] = entry
        if next_pos.y < -3 or float(entry["life"]) <= 0:
            node.queue_free()
            projectiles.remove_at(i)

func _splat(pos: Vector3) -> void:
    var decal := Node3D.new()
    decal.position = pos + Vector3(0, 0.12, 0)
    add_child(decal)
    _sphere(decal, Vector3.ZERO, Vector3(0.8, 0.08, 0.7), Color("f6f1dc"))
    get_tree().create_timer(6.0).timeout.connect(func():
        if is_instance_valid(decal):
            decal.queue_free()
    )
    splats += 1
    chaos += 15
    for i in range(people.size()):
        var ped = people[i]
        var n: Node3D = ped["node"]
        if n.global_position.distance_to(pos) < 6.0:
            ped["panic"] = 5.0
            ped["dir"] = (n.global_position - pos).normalized()
            people[i] = ped
            chaos += 25
            _notify("DIRECT HIT! THE LOCALS ARE FUMING.", 2.0)
    _sound(SPLAT)
    _update_hud()
    if mission_stage == 1 and splats >= 5:
        mission_stage = 2
        _notify("MISSION COMPLETE! FREE ROAM UNLOCKED — RULE THE SKY!", 6.0)

func _tick_people(delta: float) -> void:
    for i in range(people.size()):
        var p = people[i]
        var node: Node3D = p["node"]
        var dir: Vector3 = p["dir"]
        var panic: float = p["panic"]
        if panic > 0:
            panic -= delta
        var speed := 8.0 if panic > 0 else 1.9
        node.position += dir * speed * delta
        node.position.y = 0.32 + sin(game_time * 7.0 + float(p["phase"])) * 0.09
        if absf(node.position.x) > 235 or absf(node.position.z) > 240 or (node.position.z > 132 and node.position.z < 169):
            dir = -dir
            node.position += dir * 3.0 * delta
        elif rng.randf() < 0.002:
            dir = Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1)).normalized()
        node.rotation.y = atan2(dir.x, dir.z)
        p["dir"] = dir
        p["panic"] = panic
        people[i] = p

func _tick_cars(delta: float) -> void:
    for i in range(cars.size()):
        var c = cars[i]
        var n: Node3D = c["node"]
        if c["horizontal"]:
            n.position.x += float(c["speed"]) * delta
            n.rotation.y = PI / 2
            if n.position.x > 240:
                n.position.x = -240
        else:
            n.position.z += float(c["speed"]) * delta
            n.rotation.y = 0
            if n.position.z > 235:
                n.position.z = -235

func _tick_pickups(delta: float) -> void:
    for i in range(chip_nodes.size() - 1, -1, -1):
        var n: Node3D = chip_nodes[i]
        n.rotation.y += delta * 1.2
        if player.global_position.distance_to(n.global_position) < 2.5:
            _collect_chip(i)

func _steal_chips() -> void:
    if not started or paused or map_open:
        return
    var closest := -1
    var best := 5.5
    for i in range(chip_nodes.size()):
        var dist := player.global_position.distance_to(chip_nodes[i].global_position)
        if dist < best:
            best = dist
            closest = i
    if closest >= 0:
        _collect_chip(closest)
    else:
        _notify("NO CHIPS HERE. FIND A TAKEAWAY!", 1.7)

func _collect_chip(index: int) -> void:
    var n: Node3D = chip_nodes[index]
    n.queue_free()
    chip_nodes.remove_at(index)
    chips += 1
    chaos += 30
    _sound(CHIP)
    _notify("CHIPS NICKED! +30 CHAOS", 1.8)
    _update_hud()
    if mission_stage == 0 and chips >= 5:
        mission_stage = 1
        _notify("MISSION 2: LAND FIVE POOP SHOTS! X OR RIGHT TRIGGER!", 5.0)

func _update_hud() -> void:
    if hud == null:
        return
    hud.text = "GRAND THEFT PIGEON  |  BRISTOL CITY CENTRE     CHIPS: %d     SPLATS: %d     CHAOS: %d" % [chips, splats, chaos]
    if mission_stage == 0:
        objective.text = "MISSION 1  •  Steal five portions of chips: %d / 5" % min(chips, 5)
    elif mission_stage == 1:
        objective.text = "MISSION 2  •  Fire five poop shots: %d / 5" % min(splats, 5)
    else:
        objective.text = "FREE ROAM UNLOCKED  •  Explore rooftops, parks and the floating harbour!"

func _notify(message: String, duration: float = 2.0) -> void:
    if notice != null:
        notice.text = message
        notice_time = duration

func _sound(stream: AudioStream) -> void:
    if sound_player == null:
        return
    sound_player.stream = stream
    sound_player.play()
